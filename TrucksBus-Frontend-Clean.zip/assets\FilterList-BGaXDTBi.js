import{c as t,j as o}from"./mui-C7ASKj0e.js";const r=t(o.jsx("path",{d:"M10 18h4v-2h-4zM3 6v2h18V6zm3 7h12v-2H6z"}));export{r as F};
