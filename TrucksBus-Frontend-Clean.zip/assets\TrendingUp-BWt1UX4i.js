import{c as s,j as t}from"./mui-C7ASKj0e.js";const r=s(t.jsx("path",{d:"m16 6 2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"}));export{r as T};
