import{c as s,j as h}from"./mui-BRI06pNu-1759114965350.js";const a=s(h.jsx("path",{d:"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6zM19 4h-3.5l-1-1h-5l-1 1H5v2h14z"}));export{a as D};
