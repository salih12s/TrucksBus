import{c as h,j as s}from"./mui-BRI06pNu-1759114965350.js";const m=h(s.jsx("path",{d:"M1 21h22L12 2zm12-3h-2v-2h2zm0-4h-2v-4h2z"}));export{m as W};
