import{c as s,j as a}from"./mui-BRI06pNu-1759114965350.js";const o=s(a.jsx("path",{d:"M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"}));export{o as E};
