import{c as o,j as r}from"./mui-BdUXvIcX.js";const t=o(r.jsx("path",{d:"M8 5v14l11-7z"}));export{t as P};
