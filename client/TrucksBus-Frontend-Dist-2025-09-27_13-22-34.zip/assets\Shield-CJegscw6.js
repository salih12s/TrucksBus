import{c as s,j as t}from"./mui-BdUXvIcX.js";const a=s(t.jsx("path",{d:"M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5z"}));export{a as S};
