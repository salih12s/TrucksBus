import{c as s,j as a}from"./mui-BXklAWab.js";const o=s(a.jsx("path",{d:"M8 5v14l11-7z"}));export{o as P};
