import{c as s,j as t}from"./mui-DSg23BRN.js";const a=s(t.jsx("path",{d:"M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11"}));export{a as R};
