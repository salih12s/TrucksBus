import{c as o,j as s}from"./mui-C7ASKj0e.js";const a=o(s.jsx("path",{d:"M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"}));export{a as E};
